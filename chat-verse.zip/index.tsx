
import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { createRoot } from 'react-dom/client';
import { 
  GoogleGenAI, 
  Modality, 
  LiveServerMessage, 
  Chat 
} from '@google/genai';
import { 
  Video, 
  Mic, 
  MicOff, 
  VideoOff, 
  PhoneOff, 
  Send, 
  Users, 
  Phone,
  MoreVertical,
  Paperclip,
  Smile,
  Settings,
  Circle,
  Search,
  X,
  Lock,
  ShieldCheck,
  ShieldAlert,
  Fingerprint,
  Key,
  LogOut,
  User,
  MessageSquare,
  Hash,
  AtSign,
  Info
} from 'lucide-react';

/** 
 * SECURITY MODULE (E2EE) 
 * Using Web Crypto API for AES-GCM 256-bit encryption
 */
const CryptoEngine = {
  async deriveKey(passphrase: string, salt: string = 'nexus-v2-salt') {
    const encoder = new TextEncoder();
    const baseKey = await window.crypto.subtle.importKey(
      'raw',
      encoder.encode(passphrase),
      'PBKDF2',
      false,
      ['deriveKey']
    );
    return window.crypto.subtle.deriveKey(
      {
        name: 'PBKDF2',
        salt: encoder.encode(salt),
        iterations: 100000,
        hash: 'SHA-256'
      },
      baseKey,
      { name: 'AES-GCM', length: 256 },
      true,
      ['encrypt', 'decrypt']
    );
  },

  async encrypt(plaintext: string, key: CryptoKey) {
    const encoder = new TextEncoder();
    const iv = window.crypto.getRandomValues(new Uint8Array(12));
    const ciphertext = await window.crypto.subtle.encrypt(
      { name: 'AES-GCM', iv },
      key,
      encoder.encode(plaintext)
    );
    const combined = new Uint8Array(iv.length + ciphertext.byteLength);
    combined.set(iv);
    combined.set(new Uint8Array(ciphertext), iv.length);
    return btoa(String.fromCharCode(...combined));
  },

  async decrypt(base64: string, key: CryptoKey) {
    try {
      const combined = Uint8Array.from(atob(base64), c => c.charCodeAt(0));
      const iv = combined.slice(0, 12);
      const ciphertext = combined.slice(12);
      const decrypted = await window.crypto.subtle.decrypt(
        { name: 'AES-GCM', iv },
        key,
        ciphertext
      );
      return new TextDecoder().decode(decrypted);
    } catch (e) {
      return "[Packet Decryption Error]";
    }
  },

  async getFingerprint(key: CryptoKey) {
    const exported = await window.crypto.subtle.exportKey('raw', key);
    const hash = await window.crypto.subtle.digest('SHA-256', exported);
    return btoa(String.fromCharCode(...new Uint8Array(hash))).slice(0, 8);
  }
};

/**
 * UTILITY FUNCTIONS FOR AUDIO/VIDEO
 */
const encodeBase64 = (bytes: Uint8Array) => {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
};

const decodeBase64 = (base64: string) => {
  const binaryString = atob(base64);
  const bytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) bytes[i] = binaryString.charCodeAt(i);
  return bytes;
};

const decodeAudioData = async (data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number): Promise<AudioBuffer> => {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
};

interface Message {
  id: string;
  sender: string;
  text: string;
  timestamp: Date;
  isAi: boolean;
}

interface Contact {
  id: string;
  name: string;
  status: 'online' | 'offline' | 'away';
  avatar: string;
  lastSeen: string;
  type: 'direct' | 'group';
}

const INITIAL_CONTACTS: Contact[] = [
  { id: 'nexus-ai', name: 'Nexus Core AI', status: 'online', avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=Core', lastSeen: 'Active', type: 'direct' },
  { id: 'global-chat', name: 'Global Secure Room', status: 'online', avatar: 'https://api.dicebear.com/7.x/identicon/svg?seed=Global', lastSeen: '12 active', type: 'group' },
  { id: 'dev-ops', name: 'DevOps Security', status: 'away', avatar: 'https://api.dicebear.com/7.x/initials/svg?seed=DS', lastSeen: '5m ago', type: 'direct' },
];

const App: React.FC = () => {
  // Session State
  const [user, setUser] = useState<{ name: string; email: string; avatar: string } | null>(() => {
    const saved = localStorage.getItem('nexus_user');
    return saved ? JSON.parse(saved) : null;
  });
  const [isAuthenticated, setIsAuthenticated] = useState(!!user);
  const [loginPass, setLoginPass] = useState('');
  const [activeRoom, setActiveRoom] = useState('Secure Zone');
  
  // Security State
  const [cryptoKey, setCryptoKey] = useState<CryptoKey | null>(null);
  const [fingerprint, setFingerprint] = useState('');

  // UI State
  const [activeContact, setActiveContact] = useState<Contact>(INITIAL_CONTACTS[0]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  
  // Call State
  const [isCalling, setIsCalling] = useState(false);
  const [callSettings, setCallSettings] = useState({ muted: false, videoOff: false });

  // Refs
  const aiClient = useMemo(() => new GoogleGenAI({ apiKey: process.env.API_KEY }), []);
  const chatRef = useRef<Chat | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const liveSessionRef = useRef<any>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const audioContexts = useRef<{ input: AudioContext; output: AudioContext } | null>(null);

  // Persistence
  useEffect(() => {
    if (user) localStorage.setItem('nexus_user', JSON.stringify(user));
    else localStorage.removeItem('nexus_user');
  }, [user]);

  // Key Derivation
  useEffect(() => {
    if (isAuthenticated && loginPass) {
      CryptoEngine.deriveKey(loginPass).then(async (key) => {
        setCryptoKey(key);
        const fp = await CryptoEngine.getFingerprint(key);
        setFingerprint(fp);
      });
    }
  }, [isAuthenticated, loginPass]);

  // Chat Setup
  useEffect(() => {
    if (!isAuthenticated || !cryptoKey) return;
    chatRef.current = aiClient.chats.create({
      model: 'gemini-3-flash-preview',
      config: {
        systemInstruction: `You are the ${activeContact.name} peer in the Nexus encrypted network. 
        You are communicating in the '${activeRoom}' tunnel. 
        The current user is ${user?.name}.
        Keep responses brief, professional, and helpful.`,
      },
    });
    setMessages([{ 
      id: 'system-init', 
      sender: activeContact.name, 
      text: `Secure connection to ${activeContact.name} established in room ${activeRoom}.`, 
      timestamp: new Date(),
      isAi: true 
    }]);
  }, [activeContact, cryptoKey, isAuthenticated, activeRoom]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (loginPass.length < 4) return alert("Passphrase too short for E2EE.");
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setUser(null);
    setLoginPass('');
    setCryptoKey(null);
  };

  const sendMessage = async () => {
    if (!inputText.trim() || !chatRef.current || !cryptoKey || !user) return;
    const raw = inputText;
    setInputText('');
    
    setMessages(prev => [...prev, { id: Date.now().toString(), sender: user.name, text: raw, timestamp: new Date(), isAi: false }]);
    setIsTyping(true);
    
    try {
      const encrypted = await CryptoEngine.encrypt(raw, cryptoKey);
      const response = await chatRef.current.sendMessage({ message: `[ENC]: ${encrypted}` });
      setMessages(prev => [...prev, { id: (Date.now()+1).toString(), sender: activeContact.name, text: response.text || "...", timestamp: new Date(), isAi: true }]);
    } catch (e) {
      console.error(e);
    } finally {
      setIsTyping(false);
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const toggleCall = async () => {
    if (isCalling) {
      setIsCalling(false);
      if (liveSessionRef.current) liveSessionRef.current.close();
      if (videoRef.current?.srcObject) (videoRef.current.srcObject as MediaStream).getTracks().forEach(t => t.stop());
      audioContexts.current?.input.close();
      audioContexts.current?.output.close();
      return;
    }
    
    setIsCalling(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: true });
      if (videoRef.current) videoRef.current.srcObject = stream;
      
      const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      audioContexts.current = { input: inputCtx, output: outputCtx };

      const session = await aiClient.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            const source = inputCtx.createMediaStreamSource(stream);
            const scriptProcessor = inputCtx.createScriptProcessor(4096, 1, 1);
            scriptProcessor.onaudioprocess = (e) => {
              if (callSettings.muted) return;
              const inputData = e.inputBuffer.getChannelData(0);
              const int16 = new Int16Array(inputData.length);
              for (let i = 0; i < inputData.length; i++) int16[i] = inputData[i] * 32768;
              session.sendRealtimeInput({ media: { data: encodeBase64(new Uint8Array(int16.buffer)), mimeType: 'audio/pcm;rate=16000' } });
            };
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputCtx.destination);
          },
          onmessage: async (msg: LiveServerMessage) => {
            const audio = msg.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (audio) {
              const buf = await decodeAudioData(decodeBase64(audio), outputCtx, 24000, 1);
              const source = outputCtx.createBufferSource();
              source.buffer = buf;
              source.connect(outputCtx.destination);
              source.start();
            }
          }
        },
        config: { responseModalities: [Modality.AUDIO] }
      });
      liveSessionRef.current = session;
    } catch (e) {
      setIsCalling(false);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="h-screen bg-slate-950 flex flex-col md:flex-row items-center justify-center p-6 gap-12 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]">
        <div className="max-w-md w-full animate-in fade-in slide-in-from-left-8 duration-700">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-14 h-14 bg-blue-600 rounded-2xl flex items-center justify-center shadow-2xl shadow-blue-600/20 ring-4 ring-blue-500/10">
              <ShieldCheck className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-black text-white tracking-tight">Nexus.io</h1>
              <p className="text-slate-500 font-medium">Hyper-Secure Communication</p>
            </div>
          </div>
          <p className="text-slate-400 leading-relaxed mb-8">
            Experience military-grade encryption in your browser. Our zero-knowledge protocol ensures your keys never leave your machine.
          </p>
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 bg-slate-900/50 border border-slate-800 rounded-2xl">
              <Lock className="w-5 h-5 text-emerald-500 mb-2" />
              <h4 className="text-sm font-bold text-white">AES-GCM 256</h4>
              <p className="text-[10px] text-slate-500 uppercase tracking-widest mt-1">E2E Encryption</p>
            </div>
            <div className="p-4 bg-slate-900/50 border border-slate-800 rounded-2xl">
              <Fingerprint className="w-5 h-5 text-blue-500 mb-2" />
              <h4 className="text-sm font-bold text-white">PBKDF2</h4>
              <p className="text-[10px] text-slate-500 uppercase tracking-widest mt-1">Key Derivation</p>
            </div>
          </div>
        </div>

        <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-[2.5rem] p-10 shadow-2xl animate-in fade-in slide-in-from-bottom-8 duration-700 relative overflow-hidden group">
          <div className="absolute inset-0 bg-gradient-to-tr from-blue-600/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
          <form onSubmit={handleLogin} className="relative z-10">
            <h2 className="text-2xl font-bold text-white mb-8">Identity Portal</h2>
            <div className="space-y-5">
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Screen Name</label>
                <div className="relative">
                   <User className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                   <input 
                    required
                    className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-12 py-4 text-white placeholder:text-slate-700 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition-all"
                    placeholder="GhostAgent"
                    value={user?.name || ''}
                    onChange={e => setUser({ name: e.target.value, email: `${e.target.value.toLowerCase()}@nexus.io`, avatar: `https://api.dicebear.com/7.x/initials/svg?seed=${e.target.value}` })}
                   />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Encryption Passphrase</label>
                <div className="relative">
                   <Key className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                   <input 
                    required
                    type="password"
                    className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-12 py-4 text-white placeholder:text-slate-700 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 outline-none transition-all"
                    placeholder="Minimum 4 characters"
                    value={loginPass}
                    onChange={e => setLoginPass(e.target.value)}
                   />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Secure Room Context</label>
                <select 
                  className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-4 py-4 text-white focus:border-blue-500 outline-none transition-all appearance-none cursor-pointer"
                  value={activeRoom}
                  onChange={e => setActiveRoom(e.target.value)}
                >
                  <option>Mainframes-A</option>
                  <option>Shadow-Tunnel-01</option>
                  <option>Secure Zone</option>
                </select>
              </div>
              <button 
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-4 rounded-2xl mt-4 shadow-xl shadow-blue-600/20 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2"
              >
                Launch Protocol <ShieldCheck className="w-5 h-5" />
              </button>
            </div>
            <p className="text-center text-[10px] text-slate-600 mt-8">
              By entering, you initiate a secure WebCrypto session.
            </p>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-slate-950 text-slate-100 overflow-hidden font-sans">
      {/* Sidebar */}
      <aside className="w-80 border-r border-slate-800/50 bg-slate-900/40 flex flex-col backdrop-blur-3xl shrink-0">
        <div className="p-6">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center">
                <ShieldCheck className="w-6 h-6 text-white" />
              </div>
              <span className="text-lg font-black tracking-tight">NEXUS</span>
            </div>
            <button onClick={handleLogout} className="p-2 hover:bg-red-500/10 rounded-xl text-slate-500 hover:text-red-500 transition-colors">
              <LogOut className="w-5 h-5" />
            </button>
          </div>

          <div className="bg-slate-950/40 rounded-2xl p-4 border border-slate-800/50 flex items-center gap-4 mb-8">
            <Fingerprint className="w-6 h-6 text-emerald-500" />
            <div className="min-w-0">
               <p className="text-[10px] uppercase font-bold text-slate-500 tracking-tighter">Cipher: {fingerprint || '...'}</p>
               <p className="text-xs text-slate-400 truncate">Tunnel: {activeRoom}</p>
            </div>
          </div>

          <nav className="space-y-1">
            <h2 className="text-[10px] font-bold text-slate-600 uppercase tracking-widest px-3 mb-4">Channels & Peers</h2>
            {INITIAL_CONTACTS.map(c => (
              <button 
                key={c.id}
                onClick={() => setActiveContact(c)}
                className={`w-full flex items-center gap-3 p-3 rounded-2xl transition-all group ${activeContact.id === c.id ? 'bg-blue-600 shadow-lg shadow-blue-600/20' : 'hover:bg-slate-800/50'}`}
              >
                <div className="relative">
                   <img src={c.avatar} className="w-10 h-10 rounded-full border border-slate-800" alt="" />
                   {c.status === 'online' && <div className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 rounded-full border-2 border-slate-900" />}
                </div>
                <div className="flex-1 text-left min-w-0">
                  <p className={`text-sm font-bold truncate ${activeContact.id === c.id ? 'text-white' : 'text-slate-200'}`}>{c.name}</p>
                  <p className={`text-[10px] truncate ${activeContact.id === c.id ? 'text-blue-200' : 'text-slate-500'}`}>{c.lastSeen}</p>
                </div>
                {c.type === 'group' && <Hash className="w-3.5 h-3.5 text-slate-600" />}
              </button>
            ))}
          </nav>
        </div>

        <div className="mt-auto p-6 bg-slate-900/60 border-t border-slate-800/50">
          <div className="flex items-center gap-3">
             <img src={user?.avatar} className="w-10 h-10 rounded-full bg-slate-800 border border-slate-700" alt="" />
             <div className="flex-1 min-w-0">
               <p className="text-sm font-bold truncate">{user?.name}</p>
               <p className="text-[10px] text-emerald-500 flex items-center gap-1 font-bold"><Circle className="w-1.5 h-1.5 fill-current" /> SECURE</p>
             </div>
             <Settings className="w-5 h-5 text-slate-600 hover:text-white cursor-pointer" />
          </div>
        </div>
      </aside>

      {/* Chat Space */}
      <main className="flex-1 flex flex-col bg-slate-950 relative min-w-0">
        <header className="h-20 border-b border-slate-800/50 flex items-center justify-between px-8 bg-slate-950/80 backdrop-blur-xl z-20">
          <div className="flex items-center gap-4 min-w-0">
            <img src={activeContact.avatar} className="w-11 h-11 rounded-full shadow-2xl" alt="" />
            <div className="min-w-0">
               <h2 className="font-bold text-lg leading-tight flex items-center gap-2">
                 {activeContact.name} 
                 <ShieldCheck className="w-4 h-4 text-emerald-500" />
               </h2>
               <div className="flex items-center gap-3">
                  <p className="text-xs text-emerald-500/70 font-bold uppercase tracking-widest text-[9px]">E2EE Tunnel</p>
                  <p className="text-[10px] text-slate-600 font-mono tracking-tighter">[{fingerprint}]</p>
               </div>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <button className="p-3 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-white transition-all"><Search className="w-5 h-5" /></button>
            <button onClick={toggleCall} className="p-3 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-white transition-all"><Phone className="w-5 h-5" /></button>
            <button onClick={toggleCall} className="p-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white shadow-xl shadow-blue-600/20 transition-all active:scale-95"><Video className="w-5 h-5" /></button>
            <div className="w-px h-6 bg-slate-800 mx-2" />
            <button className="p-3 rounded-xl hover:bg-slate-800 text-slate-400"><MoreVertical className="w-5 h-5" /></button>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-8 space-y-8 custom-scrollbar bg-[radial-gradient(circle_at_center,_rgba(30,58,138,0.05)_0%,_transparent_70%)]">
          {messages.map(m => (
            <div key={m.id} className={`flex ${m.isAi ? 'justify-start' : 'justify-end'} group animate-in fade-in slide-in-from-bottom-4 duration-500`}>
              <div className={`max-w-[75%] flex flex-col ${m.isAi ? 'items-start' : 'items-end'}`}>
                <div className={`px-5 py-4 rounded-3xl relative shadow-2xl border ${m.isAi ? 'bg-slate-900 border-slate-800 text-slate-200 rounded-tl-none' : 'bg-blue-600 border-blue-500 text-white rounded-tr-none'}`}>
                  <p className="text-[15px] leading-relaxed selection:bg-white/20">{m.text}</p>
                  <div className={`absolute bottom-2 -right-12 opacity-0 group-hover:opacity-100 transition-opacity p-2 text-slate-600 ${m.isAi ? 'left-full ml-2' : 'right-full mr-2'}`}>
                    <Info className="w-4 h-4 cursor-help" />
                  </div>
                </div>
                <div className="flex items-center gap-2 mt-2 px-1">
                   <span className="text-[10px] text-slate-600 font-bold uppercase tracking-widest">{m.sender}</span>
                   <span className="text-[10px] text-slate-700 font-mono">{m.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                   {cryptoKey && <Lock className="w-2.5 h-2.5 text-emerald-500/50" />}
                </div>
              </div>
            </div>
          ))}
          {isTyping && (
             <div className="flex items-center gap-2 text-slate-600 animate-pulse px-2">
               <AtSign className="w-3 h-3" />
               <span className="text-[10px] font-bold uppercase tracking-widest">Protocol analyzing...</span>
             </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        <footer className="p-8 border-t border-slate-800/50 bg-slate-950/80 backdrop-blur-xl">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center gap-3 bg-slate-900/80 border border-slate-800 rounded-2xl p-2 px-4 shadow-2xl focus-within:ring-2 focus-within:ring-blue-500/50 focus-within:border-blue-500 transition-all">
              <button className="p-2.5 text-slate-500 hover:text-white transition-colors"><Paperclip className="w-5 h-5" /></button>
              <input 
                className="flex-1 bg-transparent border-none focus:ring-0 text-slate-100 py-4 text-base placeholder:text-slate-700"
                placeholder="Secure transmission ready..."
                value={inputText}
                onChange={e => setInputText(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && sendMessage()}
              />
              <button className="p-2.5 text-slate-500 hover:text-white transition-colors"><Smile className="w-5 h-5" /></button>
              <button 
                onClick={sendMessage}
                disabled={!inputText.trim() || !cryptoKey}
                className="p-3.5 bg-blue-600 rounded-xl hover:bg-blue-500 disabled:opacity-20 text-white shadow-xl shadow-blue-600/20 transition-all hover:scale-[1.05] active:scale-[0.95]"
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
            <div className="flex justify-center mt-3">
               <div className="flex items-center gap-1.5 px-3 py-1 bg-emerald-500/5 border border-emerald-500/10 rounded-full">
                  <ShieldCheck className="w-3 h-3 text-emerald-500" />
                  <span className="text-[9px] font-bold text-emerald-500 uppercase tracking-widest">Quantum Resistant Encryption Active</span>
               </div>
            </div>
          </div>
        </footer>

        {/* Video Call Overlay */}
        {isCalling && (
          <div className="absolute inset-0 z-[100] bg-slate-950 flex flex-col items-center justify-center animate-in fade-in duration-700">
             <div className="absolute top-12 flex flex-col items-center z-10">
                <div className="px-4 py-1.5 bg-emerald-500/10 border border-emerald-500/20 rounded-full flex items-center gap-2 mb-4">
                   <span className="w-2 h-2 bg-emerald-500 rounded-full animate-ping" />
                   <span className="text-[10px] font-bold text-emerald-500 uppercase tracking-widest">End-to-End Stream</span>
                </div>
                <h3 className="text-3xl font-black text-white">{activeContact.name}</h3>
                <p className="text-slate-500 font-mono text-sm mt-1">SSTP Protocol v2.4</p>
             </div>
             
             <div className="w-full h-full max-w-6xl max-h-[80%] grid grid-cols-1 md:grid-cols-2 gap-8 p-12">
               <div className="bg-slate-900/50 rounded-[3rem] border border-slate-800 flex items-center justify-center relative overflow-hidden group shadow-2xl">
                  <div className="absolute inset-0 flex items-center justify-center opacity-20 group-hover:opacity-40 transition-opacity">
                     <img src={activeContact.avatar} className="w-64 h-64 grayscale opacity-10" alt="" />
                  </div>
                  <div className="flex flex-col items-center z-10">
                    <img src={activeContact.avatar} className="w-40 h-40 rounded-full border-4 border-blue-600 shadow-2xl mb-8" alt="" />
                    <div className="flex gap-1 h-12 items-end">
                       {[...Array(20)].map((_, i) => (
                         <div key={i} className="w-1.5 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: `${i * 0.05}s`, height: `${30 + Math.random() * 70}%` }} />
                       ))}
                    </div>
                  </div>
               </div>

               <div className="bg-slate-900 rounded-[3rem] border-4 border-slate-800 overflow-hidden relative shadow-2xl">
                  <video ref={videoRef} autoPlay muted playsInline className={`w-full h-full object-cover transform scale-x-[-1] ${callSettings.videoOff ? 'hidden' : ''}`} />
                  {callSettings.videoOff && (
                    <div className="w-full h-full flex flex-col items-center justify-center">
                      <div className="w-24 h-24 bg-slate-800 rounded-full flex items-center justify-center mb-4">
                        <VideoOff className="w-10 h-10 text-slate-600" />
                      </div>
                      <span className="text-slate-600 font-bold text-xs uppercase tracking-widest">Video Muted</span>
                    </div>
                  )}
               </div>
             </div>

             <div className="mt-auto mb-16 flex items-center gap-8 bg-slate-900/80 p-6 rounded-[2.5rem] border border-slate-800 shadow-2xl backdrop-blur-xl">
               <button onClick={() => setCallSettings(s => ({...s, muted: !s.muted}))} className={`p-6 rounded-full border transition-all ${callSettings.muted ? 'bg-red-500/20 border-red-500 text-red-500' : 'bg-slate-800 border-slate-700 hover:bg-slate-700 text-white'}`}>
                 {callSettings.muted ? <MicOff className="w-8 h-8" /> : <Mic className="w-8 h-8" />}
               </button>
               <button onClick={toggleCall} className="p-8 rounded-full bg-red-600 hover:bg-red-500 text-white shadow-2xl shadow-red-600/40 hover:scale-110 active:scale-90 transition-all">
                 <PhoneOff className="w-10 h-10" />
               </button>
               <button onClick={() => setCallSettings(s => ({...s, videoOff: !s.videoOff}))} className={`p-6 rounded-full border transition-all ${callSettings.videoOff ? 'bg-red-500/20 border-red-500 text-red-500' : 'bg-slate-800 border-slate-700 hover:bg-slate-700 text-white'}`}>
                 {callSettings.videoOff ? <VideoOff className="w-8 h-8" /> : <Video className="w-8 h-8" />}
               </button>
             </div>
          </div>
        )}
      </main>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #334155; border-radius: 10px; }
        @keyframes fade-in { from { opacity: 0; } to { opacity: 1; } }
        @keyframes slide-in-from-bottom { from { transform: translateY(12px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        .animate-in { animation: 0.3s ease-out both; }
        .fade-in { animation-name: fade-in; }
        .slide-in-from-bottom-4 { animation-name: slide-in-from-bottom; }
      `}</style>
    </div>
  );
};

const root = createRoot(document.getElementById('root')!);
root.render(<App />);
